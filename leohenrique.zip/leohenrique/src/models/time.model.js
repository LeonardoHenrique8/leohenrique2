module.exports = (sequelize, DataTypes) => {
  const time = sequelize.define('time', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nome: DataTypes.STRING,
    estado: DataTypes.STRING,
    sites: DataTypes.STRING
  }, {
    timestamps: false,
    freezeTableName: true
  })

  return time
}
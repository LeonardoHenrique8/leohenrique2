const timeService = require('../service/time.service')

const listAll = async (req, res) => {
  const item = await timeService.listAll()
  res.send(item)
  res.status(200)
}

module.exports = {
  listAll
}
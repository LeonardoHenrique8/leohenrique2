const express = require('express')
const timeRoute = require('./route/time.route')


const app = express()
app.use(express.json())
app.use('/times', timeRoute)


app.get('/', (req, res) => {
  res.send('Prova 2!')
})

const PORT = 8087
app.listen(PORT, () => {
  console.log(`Server started on port: ${PORT}`)
})

const express = require('express')
const timeController = require('../controller/time.controller')

const router = express.Router()

router.get('/api/v1/teams/', timeController.listAll)

module.exports = router

create table timess(
  id serial primary key,
  nome varchar(50) not null,
  estado varchar(2) not null,
  sites varchar(50) not null
);

INSERT INTO timess (nome, estado, sites) VALUES ('Sao Paulo','SP','https://www.saopaulofc.net/');
INSERT INTO timess (nome, estado, sites) VALUES ('Atlético Mineiro','MG','https://www.atletico.com.br/');


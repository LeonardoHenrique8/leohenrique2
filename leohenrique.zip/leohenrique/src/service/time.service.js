const { time } = require('../models/index')

const listAll = async () => {
  return item = await time.findAll()
}

module.exports = {
  listAll
}